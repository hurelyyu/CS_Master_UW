Yaqun Yu and Xiao Liang 558 Project4 ReadMe
******************************************************************
5 Servers, Client, random kill server to check Paxos consistency
******************************************************************

How TO TEST:

To run the code on the nodes:

1.Copy the following files to n01, n02, n03, n04, n05:
		all project4
		
2.Copy the following files to n06, n07:
		all project4
		
3.Run the following commands on n01, n02, n03, n04, n05 with all project4, 
	respectively:
		java RMIServer 1 n02, n03, n04, n05
		java RMIServer 2 n01, n03, n04, n05
		java RMIServer 3 n01, n02, n04, n05
		java RMIServer 4 n01, n02, n03, n05
		java RMIServer 5 n01, n02, n03, n04
		
The arguments for the Server.jar, are the server id and the node addresses of servers       you want to replicate to.

4.Run the following commands on n06 and n07 with the all project4,
	respectively:
		java RMIClient n06
		java RMIClient n07
		
		The argument for the Client.jar, is the address of the server you want 
		to connect to.

************************
For VM on school server:
************************

1. get into 558 project VM n01, use as client, use $ mkdir Client command create Client folder
2. put Client files on /home/NetID/Client/
3. open another VM n02, use as server, use $ mkdir Server command create Server folder
4. put Server files on /home/NetID/Server/ through VM n01
5. repeat local instruction for each side.
6. command to check file: $ vi <File full name, ex: RMIServerLog.txt>


*******************ATTENTION!!!***************
1. In order to test exception can also works, we put some error test situation into our test set on purpose. 
2. In case our txt file change format, we print out a pdf version in our document as well
3. Default Server port would be 1099
4. $ ifconfig command can get ip address
5. if communication fail or IP address is incorrect, Exception will throw and write in log